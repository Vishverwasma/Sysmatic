package com.app.HabitTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HabitTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
